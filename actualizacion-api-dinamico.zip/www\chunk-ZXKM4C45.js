import{b as a,c as b}from"./chunk-SJQUJGOI.js";import"./chunk-V6SBLSES.js";export{a as GESTURE_CONTROLLER,b as createGesture};
