import { AfterViewInit, Component } from '@angular/core';
import { IonHeader, IonToolbar, IonTitle, IonContent } from '@ionic/angular';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { animate, JSAnimation } from 'animejs';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  imports: [IonHeader, IonToolbar, IonTitle, IonContent, ExploreContainerComponent],
})
export class Tab1Page implements AfterViewInit {
  private currentAnimation: JSAnimation | null = null;

  ngAfterViewInit(): void {
    const email = document.querySelector('#email');
    const password = document.querySelector('#password');
    const submit = document.querySelector('#submit');

    email?.addEventListener('focus', () => {
      this.animatePath(0, '240 1386');
    });

    password?.addEventListener('focus', () => {
      this.animatePath(-336, '240 1386');
    });

    submit?.addEventListener('focus', () => {
      this.animatePath(-730, '530 1386');
    });
  }

  private animatePath(
    strokeDashoffset: number,
    strokeDasharray: string,
  ): void {
    this.currentAnimation?.pause();

    this.currentAnimation = animate('path', {
      strokeDashoffset,
      strokeDasharray,
      duration: 700,
      ease: 'outQuart',
    });
  }
}
